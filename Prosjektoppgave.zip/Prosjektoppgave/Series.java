import java.util.ArrayList;

public Series()
{
	ArrayList<Magazine> magazines;
	String publisher;
	int releasesPerYear;
	
	public Series(ArrayList<Magazine> magazines, String publisher, int releasesPerYear)
	{
		this.magazines = magazines;
		this.publisher = publiser;
		this.releasesPerYear = releasesPerYear;
	}
	
	public addMagazine(int thisRelease, Date date)
	{
		magazines.add(new Magazine(thisRelease, date));
	}
	
}